-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- 主机： 127.0.0.1
-- 生成日期： 2020-06-03 17:29:33
-- 服务器版本： 10.4.11-MariaDB
-- PHP 版本： 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 数据库： `ourteam`
--

-- --------------------------------------------------------

--
-- 表的结构 `article`
--

CREATE TABLE `article` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` varchar(1023) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- 转存表中的数据 `article`
--

INSERT INTO `article` (`id`, `title`, `content`) VALUES
(1, '测试文章', '测试'),
(2, '截止至5月31日10时，国内疫情最新进展', '新冠病毒疫情在国内的发展趋势已经逐渐明朗，很多小伙伴都会关注每日的疫情统计更新数据，从最新数据可以看出，国内的疫情趋势进一步好转，在确诊患者当中，大部分都是境外输入患者，或者是无症状感染者。钟院士表示，新冠病毒疫情在国内发生二次爆发的概率几乎为零，虽然世界范围内的病毒疫情发展仍然非常迅猛，但是由于我国针对港口以及机场的防控和封锁措施都非常严格，所以普通民众有非常大的信心和把握，病毒疫情在接下来的一段时间内会逐渐从我国被根除。 '),
(3, '武汉大学：6月8日起毕业生可分批次返校 ', '人民网武汉6月2日电 武汉大学1日晚间发布通报称，现居境内的毕业生和有科研任务的研究生，按照错时错峰、自愿申请原则，自6月8日起可分批次返校。 按照武汉大学新冠肺炎疫情防控指挥部的返校要求，武大毕业生在6月8日-11日、6月14日-17日两个时间段内分批返校，各学院、系（培养单位）会将返校须知、返校流程及相关要求提前告知毕业生。 有科研任务的研究生自6月8日起可以向所在学院、系（培养单位）提交申请，经批准后方可返校。 此外，其他非毕业年级的学生、尚在境外的学生暂不返校，具体返校时间另行通知。');

--
-- 转储表的索引
--

--
-- 表的索引 `article`
--
ALTER TABLE `article`
  ADD PRIMARY KEY (`id`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `article`
--
ALTER TABLE `article`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
